#! /bin/bash

chmod 700 /opt/pam/CyberArk/monitoring/*.sh
yes | cp -rf /opt/pam/CyberArk/monitoring/*.sh /opt/pam/monitoring
